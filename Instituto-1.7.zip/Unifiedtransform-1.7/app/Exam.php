<?php

namespace App;

use App\Model;

class Exam extends Model
{
    //
}
