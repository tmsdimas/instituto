<?php

namespace App;

use App\Model;

class Fee extends Model
{
    //
}
